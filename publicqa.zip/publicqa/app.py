from flask import Flask, request, jsonify
from deeppavlov import configs
from deeppavlov.core.common.file import read_json
from deeppavlov import configs, train_model
from deeppavlov.core.commands.infer import build_model
from nltk.tokenize import word_tokenize
import json
import pandas as pd
import tensorflow as tf
import time
import argparse
import re
from deeppavlov import configs
from deeppavlov.core.common.file import read_json
from deeppavlov import configs, train_model
from deeppavlov.core.commands.infer import build_model
import wiki_sqlite
squad = build_model(configs.squad.multi_squad_noans, download=True)

# Using Argparse to accept options in Command Line
parser = argparse.ArgumentParser()
parser.add_argument("--debug", action="store_true", help="Run in Debug Mode")
args = parser.parse_args()

# Init App
app = Flask("PublicQA")

#app_properties_file = open("system.json", "r")
#app_properties = json.load(app_properties_file)
#app_properties_file.close()

print("Loading Config:")
unified_config_file = open( "unified.odqa.json", "r")
unified_config = json.load(unified_config_file)
unified_config_file.close()

# Do not download the ODQA models, we've just trained it
unified=build_model(unified_config, download=False)

print("TensorFlow GPU: ", tf.test.is_gpu_available())

@app.route('/ask', methods=['POST'])
def ask():
	print("JSON-----------------------------------------------------------",request.get_json(force=True))
	question = request.get_json(force=True)['text']
	procQuestion=re.sub('[^a-zA-Z\w\s]','',question)
	procQuestion=re.sub('what are','',procQuestion)
	procQuestion=re.sub('what','',procQuestion)
	print("Question------------------------------------------------------",procQuestion)
	tickerL=[]
	company=[]
	if((request.get_json(force=True)).get('entities')):
		ticker=request.get_json(force=True)['entities']
	else:
		ticker=[]
	for i in range(len(ticker)):
		if(ticker[i]['entity']=='company'):
			companyStart=ticker[i]['start']
			companyEnd=ticker[i]['end']
			company.append(question[int(companyStart):int(companyEnd)])
			ticker=ticker[i]['value'].upper()
			tickerL.append((ticker))
	for word in company:
		if(len(company)>1):
			procQuestion=re.sub(word,"",procQuestion)
			procQuestion=re.sub("and","they",procQuestion)
		else:
			procQuestion=re.sub(word,"they",procQuestion)
	wiki_sqlite.ticker=tickerL
	answer_tuples = unified([procQuestion])
	answers_df=pd.DataFrame(answer_tuples, columns=["answer", "index", "confidence", "context","company"])
	answers_df = answers_df[answers_df["index"]>0]
	answers_df1=answers_df
	answers=answers_df1.to_dict('records')
	response = {
		"question": procQuestion,
		"answers": answers
	}
	
	return jsonify(response)


# Run Server
if __name__ == '__main__':
	app.run(host='0.0.0.0', debug=False)
